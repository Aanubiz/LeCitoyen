package cm.logram.lecitoyen.boommenu.BoomButtons;

public interface OnBMClickListener {
    void onBoomButtonClick(int index);

}
