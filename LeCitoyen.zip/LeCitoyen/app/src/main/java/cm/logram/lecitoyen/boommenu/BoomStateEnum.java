package cm.logram.lecitoyen.boommenu;

enum BoomStateEnum {
    DidBoom,
    WillBoom,
    DidReboom,
    WillReboom
}
