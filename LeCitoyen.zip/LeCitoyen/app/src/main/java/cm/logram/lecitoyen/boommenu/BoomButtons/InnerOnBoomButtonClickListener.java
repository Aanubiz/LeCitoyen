package cm.logram.lecitoyen.boommenu.BoomButtons;

public interface InnerOnBoomButtonClickListener {

    void onButtonClick(int index, BoomButton boomButton);

}
