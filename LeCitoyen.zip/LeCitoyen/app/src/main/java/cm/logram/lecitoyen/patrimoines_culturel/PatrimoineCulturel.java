package cm.logram.lecitoyen.patrimoines_culturel;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import cm.logram.lecitoyen.R;

public class PatrimoineCulturel extends AppCompatActivity {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_patrimoine_culturel);
  }
}
